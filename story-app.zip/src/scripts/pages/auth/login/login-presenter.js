import CONFIG from "../../../config";

export default class LoginPresenter {
    #view;
    #model;
    #authModel;

    constructor({view, model, authModel}) {
        this.#view = view;
        this.#model = model;
        this.#authModel = authModel;
    }

    async getLogin({email, password}) {
        this.#view.showLoading(true);
        try {
            const response = await this.#model.getLogin({email, password});

            if (!response.ok) {
                console.error("getLogin: response:", response);
                this.#view.loginFailed(response.message);
                return;
            }

            this.#authModel.putAccessToken(response.loginResult.token);
            localStorage.setItem(CONFIG.ACCOUNT_OWNER, response.loginResult.name)
            
            this.#view.loginSuccessfully(response.message, response.loginResult);
        } catch (error) {
            console.error("getLogin: error:", error);
            this.#view.loginFailed(response.message);
        } finally {
            this.#view.showLoading(false);
        }
    }
}